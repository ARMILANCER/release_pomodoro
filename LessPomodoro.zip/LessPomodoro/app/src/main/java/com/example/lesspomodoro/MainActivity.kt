package com.example.lesspomodoro
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.lang.Thread.sleep
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private lateinit var button: Button
    private lateinit var counter: TextView
    private var isCounting = true
    private val handler = Handler(Looper.getMainLooper())
    private var state : TextView? = null
    private var increment = 20
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        button = findViewById(R.id.origin)
        counter = findViewById(R.id.txt_counter)

        state = findViewById(R.id.state)

        button.setOnClickListener {
            if (isCounting) {
                startCounting()
            } else {
                stopCounting()
            }
        }
    }
    private fun startCounting() {
        isCounting = false
        state?.text = "FLOW"
        handler.removeCallbacks(release)
        handler.postDelayed(flow,1000)
    }
    private fun stopCounting() {
        this.isCounting = true
        state?.text = "RELEASE"
        handler.removeCallbacks(flow)
        handler.postDelayed(release,1000)
    }
    private val flow = object : Runnable{
        override fun run() {
            increment+=1
            counter.text = increment.toString()
            handler.postDelayed(this, 1000)
        }
    }
    private  val release = object : Runnable{
        var decrement = (increment*0.15).toInt()
        override fun run() {
            if (decrement > 0) {
                decrement -= 1
                counter.text = decrement.toString()
                handler.postDelayed(this, 1000)
            } else {
                startCounting()
            }
        }
    }
}